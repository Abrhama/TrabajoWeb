let map = L.map("map").setView([37.49165,-2.77998],17)
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);
L.marker([51.5, -0.09]).addTo(map)
L.Routing.control({
    waypoints: [
      L.latLng(37.49165,-2.77998),
      L.latLng(57.6792, 11.949)
    ]
  }).addTo(map);
